"""Current version of package ugly_csv_generator"""

__version__ = "1.1.0"
