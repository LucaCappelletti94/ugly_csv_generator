"""Python package to generate ugly real-looking csvs."""

from ugly_csv_generator.uglify import uglify

__all__ = ["uglify"]
