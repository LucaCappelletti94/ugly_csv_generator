from .uglify import uglify

__all__ = [
    "uglify"
]