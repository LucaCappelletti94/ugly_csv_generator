"""Current version of package ugly_csv_generator"""
__version__ = "1.0.1"